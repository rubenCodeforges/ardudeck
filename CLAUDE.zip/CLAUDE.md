  This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

  # ArduDeck - Mission Planner Modernization Project

  ## Project Overview
  Modernizing ArduPilot's Mission Planner ground control station from legacy C#/.NET WinForms to a cross-platform solution using Electron (desktop) and Flutter (mobile).

  ## Project Context

  | Component | Location | Stack |
  |-----------|----------|-------|
  | Legacy Reference | `/MissionPlanner/` | C# .NET WinForms (read-only) |
  | Desktop App | `/apps/desktop/` | Electron + React 18 + TypeScript + Vite |
  | Mobile App | `/apps/mobile/` | Flutter (Dart) - planned |
  | MAVLink Library | `/packages/mavlink-ts/` | TypeScript |
  | MSP Library | `/packages/msp-ts/` | TypeScript (Betaflight/iNav) |
  | Comms Library | `/packages/comms/` | TypeScript (Serial/TCP/UDP) |
  | STM32 DFU Library | `/packages/stm32-dfu/` | TypeScript (USB DFU) |
  | MAVLink Generator | `/tools/mavlink-generator/` | TypeScript |

  **Key Reference:** [BlueRobotics Cockpit](https://github.com/bluerobotics/cockpit) - study their MAVLink TypeScript implementation.

  ---

  ## CRITICAL: Potential BSOD Issue During Firmware Flashing (2026-01-02)

  **Status:** Under investigation - may be causing Windows blue screen crashes

  ### Symptoms
  - Windows BSOD with bug check `0x0000000A` (IRQL_NOT_LESS_OR_EQUAL)
  - Crashes occur while ArduDeck is running, especially during firmware flashing
  - USB HID device driver (WUDFRd) failing to load: `HID\VID_0909&PID_001C&MI_03`
  - Multiple crashes on same system (2:35 PM and 11:21 PM on 2026-01-02)

  ### Crash Details
  Bug Check: 0x0000000A (IRQL_NOT_LESS_OR_EQUAL)
  Parameters: 0xffffbb0345e27a00, 0x2, 0x1, 0xfffff80218c30773
  Minidumps: C:\WINDOWS\Minidump\010226-23609-01.dmp, 010226-24125-01.dmp

  ### Likely Cause
  The firmware flashing operation (Serial bootloader or DFU) may be triggering a bug in:
  1. **USB-to-serial chip driver** (CH340, CP210x, FTDI, etc.)
  2. **Windows UMDF driver** (WUDFRd) for USB HID devices
  3. **STM32 DFU driver** interactions

  ### Investigation Tasks
  - [ ] Review `main/firmware/stm32-serial-flasher.ts` for aggressive serial port operations
  - [ ] Review `main/firmware/dfu-flasher.ts` for USB handling issues
  - [ ] Review `packages/stm32-dfu/` for potential driver stress patterns
  - [ ] Add error handling/retry logic to prevent driver stress
  - [ ] Consider adding delays between USB operations
  - [ ] Test on multiple systems to reproduce
  - [ ] Check if serial port is properly closed on errors/disconnects

  ### Temporary Workaround
  Users experiencing crashes should:
  1. Update USB-serial drivers (CH340, CP210x, FTDI)
  2. Avoid firmware flashing until issue is resolved
  3. Use telemetry-only mode for testing

  ---

  ## NPM-Publishable Packages

  These packages are designed as standalone libraries that could be published to npm:

  | Package | npm Name | Description | Status |
  |---------|----------|-------------|--------|
  | `packages/mavlink-ts/` | `@ardudeck/mavlink-ts` | Full MAVLink v1/v2 protocol parser, 352 messages, async generator API | Ready |
  | `packages/msp-ts/` | `@ardudeck/msp-ts` | MSP v1/v2 protocol for Betaflight/iNav/Cleanflight, telemetry + config | Ready |
  | `packages/comms/` | `@ardudeck/comms` | Transport abstraction (Serial/TCP/UDP), port scanner | Ready |
  | `packages/stm32-dfu/` | `@ardudeck/stm32-dfu` | Native STM32 DFU flashing via libusb, cross-platform | Planned |

  **Publishing checklist:**
  - [ ] Add README.md with API docs
  - [ ] Add LICENSE file
  - [ ] Add repository/homepage to package.json
  - [ ] Version bump and changelog
  - [ ] `npm publish --access public`

  ## Build Commands

  ```bash
  pnpm install                    # Install dependencies
  pnpm build                      # Build all packages
  pnpm dev                        # Run dev mode

  # Specific builds
  pnpm --filter @ardudeck/mavlink-ts build
  pnpm --filter @ardudeck/mavlink-generator build
  node tools/mavlink-generator/dist/index.js  # Generate MAVLink types

  Assets

  - Icons: apps/desktop/resources/ - icon.ico, icon.icns, icon.png, logo.png
  - UI Assets: apps/desktop/src/renderer/assets/ - icon.png (32px), logo.png (192px)
  - Generate icons: npx png2icons resources/logo.png resources/icon -allwe

  ---
  Implementation Status

  Completed Epics

  | Epic                | Description                                                   | Key Packages/Files                                |
  |---------------------|---------------------------------------------------------------|---------------------------------------------------|
  | 1. Foundation       | Monorepo, MAVLink parser, comms layer, Electron shell         | packages/mavlink-ts/, packages/comms/             |
  | 2. Telemetry        | Real-time telemetry display, attitude indicator, GPS, battery | stores/telemetry-store.ts, TelemetryDashboard.tsx |
  | 2.5. Dashboard      | Dockable panels with dockview-react, layout persistence       | stores/layout-store.ts, components/panels/        |
  | 2.6. Map            | Leaflet map with vehicle tracking, layers, overlays           | MapPanel.tsx                                      |
  | 3. Parameters       | Full parameter management with metadata, validation, file ops | stores/parameter-store.ts, ParametersView.tsx     |
  | 4. Mission          | Mission planning with waypoints, splines, terrain profile     | stores/mission-store.ts, MissionMapPanel.tsx      |
  | 4.5. Settings       | Vehicle profiles, weather widget, performance estimates       | stores/settings-store.ts, SettingsView.tsx        |
  | 4.7. Geofence/Rally | Geofence polygons/circles, rally points                       | stores/fence-store.ts, stores/rally-store.ts      |

  Key Features Implemented

  - Connection: Serial/TCP/UDP with heartbeat validation, MAVLink v1/v2 auto-detection, MSP for Betaflight/iNav
  - Telemetry: Attitude, altitude, speed, battery, GPS with dockable panel layout
  - Parameters: Auto-load from FC, ~600 fallback descriptions, range/enum validation, flash write
  - MSP Config: Betaflight/iNav PID tuning with presets, rate curves, mode visualization, custom profile saving
  - Mission: Waypoint CRUD, spline curves, terrain-aware altitude profile, drag-to-edit (MAVLink/iNav only)
  - Geofencing: Inclusion/exclusion polygons and circles, return point
  - Rally Points: Emergency landing locations with full editing
  - Settings: Vehicle profiles with mm/inches frame size toggle, weather widget with IP geolocation fallback

  In Progress / Future

  | Epic              | Description                                             | Status      |
  |-------------------|---------------------------------------------------------|-------------|
  | 5. Firmware Flash | Flash ArduPilot/PX4/Betaflight firmware                 | ✅ Complete |
  | 6. Calibration    | Compass, accelerometer, radio, ESC calibration wizards  | Next up     |
  | 7. Setup Wizards  | Vehicle setup, frame config, motor test, receiver setup | Planned     |
  | 8. Production     | Auto-updater, crash reporting, mobile app               | Planned     |

  ---
  Critical Technical Notes

  MAVLink v2 Payload Byte Order

  MAVLink v2 orders payload fields by SIZE (largest first), NOT declaration order!

  HEARTBEAT wire order: custom_mode(4), type(1), autopilot(1), base_mode(1), ...
  VFR_HUD wire order: airspeed(4), groundspeed(4), alt(4), climb(4), heading(2), throttle(2)

  MAVLink v1 with v2 Byte Order (ArduPilot quirk)

  ArduPilot uses v2 byte order even with v1 packet framing! Affects:
  - MISSION_COUNT (44), MISSION_REQUEST (40), MISSION_REQUEST_INT (51), MISSION_SET_CURRENT (41)

  Detection strategy:
  const looksLikeV2Order = (payload[2] === 0xFF && payload[3] === 0xBE) || countAtOffset2 > 1000;

  MAVLink Messages Reference

  | Category    | Messages                                                                                         |
  |-------------|--------------------------------------------------------------------------------------------------|
  | Telemetry   | HEARTBEAT(0), SYS_STATUS(1), GPS_RAW_INT(24), ATTITUDE(30), GLOBAL_POSITION_INT(33), VFR_HUD(74) |
  | Parameters  | PARAM_REQUEST_LIST(21), PARAM_VALUE(22), PARAM_SET(23), COMMAND_LONG(76)                         |
  | Mission     | MISSION_REQUEST_LIST(43), MISSION_COUNT(44), MISSION_ITEM_INT(73), MISSION_ACK(47)               |
  | Fence/Rally | Same as mission with mission_type=1 (fence) or 2 (rally)                                         |

  Parameter Metadata URLs

  https://autotest.ardupilot.org/Parameters/ArduCopter/apm.pdef.xml
  https://autotest.ardupilot.org/Parameters/ArduPlane/apm.pdef.xml
  https://autotest.ardupilot.org/Parameters/Rover/apm.pdef.xml
  https://autotest.ardupilot.org/Parameters/ArduSub/apm.pdef.xml

  Map Layers (No API Keys)

  | Layer     | URL                                                                                           |
  |-----------|-----------------------------------------------------------------------------------------------|
  | Street    | https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png                                            |
  | Satellite | https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x} |
  | Terrain   | https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png                                              |
  | Dark      | https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png                                 |

  Terrain API

  Open-Meteo Elevation API (free, no key): renderer/utils/elevation-api.ts

  ---
  Key File Reference

  Core

  | File                                           | Purpose               |
  |------------------------------------------------|-----------------------|
  | packages/mavlink-ts/src/core/mavlink-parser.ts | MAVLink packet parser |
  | packages/comms/src/interfaces/transport.ts     | Transport interface   |
  | apps/desktop/src/main/ipc-handlers.ts          | All IPC handlers      |
  | apps/desktop/src/main/preload.ts               | Renderer API          |

  Stores (Zustand)

  | File                          | Purpose                               |
  |-------------------------------|---------------------------------------|
  | stores/telemetry-store.ts     | Vehicle telemetry state               |
  | stores/parameter-store.ts     | FC parameters                         |
  | stores/mission-store.ts       | Mission waypoints                     |
  | stores/fence-store.ts         | Geofence polygons/circles             |
  | stores/rally-store.ts         | Rally points                          |
  | stores/settings-store.ts      | App settings, vehicle profiles        |
  | stores/layout-store.ts        | Dockview panel layouts                |
  | stores/navigation-store.ts    | View switching                        |
  | stores/edit-mode-store.ts     | Mission/geofence/rally mode           |
  | stores/firmware-store.ts      | Firmware flash state, board detection |
  | stores/msp-telemetry-store.ts | MSP telemetry state (Betaflight/iNav) |

  Shared Types

  | File                      | Purpose                                    |
  |---------------------------|--------------------------------------------|
  | shared/telemetry-types.ts | FlightState, AttitudeData, GpsData, etc.   |
  | shared/parameter-types.ts | Parameter, fallback descriptions           |
  | shared/mission-types.ts   | MissionItem, MAV_CMD, MAV_FRAME            |
  | shared/fence-types.ts     | FenceItem, PolygonFence, CircleFence       |
  | shared/rally-types.ts     | RallyPoint, RALLY_FLAGS                    |
  | shared/ipc-channels.ts    | IPC channel constants, schemas             |
  | shared/firmware-types.ts  | DetectedBoard, FirmwareVersion, FlashState |
  | shared/board-ids.ts       | ArduPilot board ID mappings (150+ boards)  |

  Key Components

  | File                                          | Purpose                                                 |
  |-----------------------------------------------|---------------------------------------------------------|
  | components/panels/AttitudePanel.tsx           | Scalable attitude indicator (exportable)                |
  | components/panels/MapPanel.tsx                | Telemetry map with overlays                             |
  | components/mission/MissionMapPanel.tsx        | Mission planning map                                    |
  | components/mission/AltitudeProfilePanel.tsx   | Terrain-aware altitude chart                            |
  | components/parameters/ParametersView.tsx      | Parameter table UI                                      |
  | components/settings/SettingsView.tsx          | Settings with vehicle profiles                          |
  | components/firmware/FirmwareFlashView.tsx     | Firmware flash UI with vehicle/board pickers            |
  | components/firmware/BoardPicker.tsx           | Searchable board dropdown with categories               |
  | components/parameters/MspConfigView.tsx       | Betaflight/iNav PID/Rates/Modes configuration           |
  | components/telemetry/TelemetryDashboard.tsx   | Dockable telemetry panels with protocol-aware filtering |
  | components/betaflight/BetaflightDashboard.tsx | MSP telemetry dashboard for Betaflight/iNav             |
  | main/msp/msp-handlers.ts                      | MSP IPC handlers for telemetry and config               |

  ---
  MSP Protocol Support (Betaflight/iNav)

  Full MSP v1/v2 protocol support for Betaflight and iNav flight controllers.

  Features

  - Auto-detection: Protocol auto-detect (MAVLink vs MSP) on connection
  - Telemetry: Attitude, sensors, RC channels, motor outputs via MSP
  - PID Tuning: Beginner-friendly presets (Beginner/Freestyle/Racing/Cinematic)
  - Rate Curves: Visual rate curve editor with presets
  - Modes Wizard: Step-by-step mode configuration with presets, live RC feedback ✅
  - Custom Profiles: Save/load custom PID tunes and rate profiles (localStorage)
  - Protocol-aware UI: Mission planning hidden for Betaflight (not supported)

  MSP Files

  | File                                     | Purpose                                                      |
  |------------------------------------------|--------------------------------------------------------------|
  | packages/msp-ts/                         | MSP v1/v2 parser, message definitions                        |
  | main/msp/msp-handlers.ts                 | MSP IPC handlers (mspGetPid, mspSetRcTuning, mspGetRc, etc.) |
  | components/parameters/MspConfigView.tsx  | PID/Rates/Modes UI with presets                              |
  | components/parameters/ServoMixerTab.tsx  | iNav servo mixer configuration                               |
  | components/parameters/NavigationTab.tsx  | iNav navigation/RTH settings                                 |
  | components/modes/ModesWizard.tsx         | Modes setup wizard modal                                     |
  | components/modes/ModesAdvancedEditor.tsx | Full table editor for modes                                  |
  | stores/modes-wizard-store.ts             | Modes wizard state, RC polling                               |
  | main/firmware/msp-detector.ts            | MSP board detection                                          |

  iNav Enhancements

  MspConfigView now includes iNav-specific features:
  - Servo mixer tab: Configure servo outputs/mixing for fixed-wing (elevons, v-tail, flaperons)
  - Navigation tab: RTH altitude, nav speeds, GPS config, landing settings
  - Beginner-friendly explanations: Header info boxes explain concepts in plain language

  Still TODO:
  - Fixed-wing detection: Show Servo Mixer tab only for fixed-wing iNav builds (detect via MSP_MIXER_CONFIG)
  - PIFF tuning: iNav uses PIFF controller (not PID) for position
  - Programming tab: iNav's logic conditions framework

  ---
  Epic 5: Firmware Flash

  Flash firmware directly from ArduDeck.

  5.1 Board Detection ✅ COMPLETE

  - Multi-protocol auto-detect: MAVLink → MSP → STM32 bootloader (plug-and-play)
  - USB VID/PID detection: 30+ known boards in KNOWN_BOARDS map
  - MAVLink detection: Queries AUTOPILOT_VERSION for board_version ID
  - MSP detection: Queries Betaflight/iNav/Cleanflight boards via MSP protocol
  - STM32 bootloader: Probes USART bootloader for chip ID
  - Board ID mapping: 150+ ArduPilot boards from board_types.txt
  - Auto-select: Detected board auto-selects in dropdown

  5.2 Manifest & Version Fetching ✅ COMPLETE

  - ArduPilot manifest parsing (firmware.ardupilot.org/manifest.json)
  - Betaflight/iNav curated versions with correct GitHub URLs
  - Version grouping (4.5.x, 4.4.x, etc.) with Latest badge
  - Stable/Beta/Dev filtering
  - File size display in version dropdown

  5.3 Firmware Download ✅ COMPLETE

  - Download .hex/.bin/.apj files from firmware servers
  - Progress tracking with byte counts
  - Caching downloaded firmware (temp directory)
  - Proper file extension handling for HEX parsing

  5.4 Flash Operation ✅ COMPLETE

  - STM32 Serial Bootloader: Full AN3155 protocol implementation
  - Boot Pad Wizard: Step-by-step guide for manual bootloader entry
  - DFU Flashing: Native @ardudeck/stm32-dfu package (no external tools)
  - Firmware Validation: Size check against chip flash capacity
  - Progress & Logging: Real-time progress bar and debug console
  - Polling-based serial communication (reliable ACK handling)
  - Auto-detect already-synced bootloader state

  5.5 F3 Board Support (Legacy)

  F3 boards have limited flash (256KB) and are not supported by modern firmware:
  - Betaflight: 3.5.7 (last version with F3 support)
  - iNav: Varies by board:
    - SPRacing F3/EVO/Mini/Neo: iNav 2.0.0 (dropped in 2.1.0)
    - FrSky F3, Airhero F3: iNav 2.6.1 (last F3 version)
  - Board mappings: shared/board-mappings.ts categorizes F3 boards
  - HEX size conversion: hexToBinarySize() estimates binary from HEX file size

  Firmware Files

  | File                                      | Purpose                                                         |
  |-------------------------------------------|-----------------------------------------------------------------|
  | main/firmware/stm32-serial-flasher.ts     | STM32 USART bootloader flashing (AN3155)                        |
  | main/firmware/dfu-flasher.ts              | Native DFU flashing via stm32-dfu package                       |
  | main/firmware/msp-detector.ts             | MSP protocol detection for Betaflight/iNav                      |
  | main/firmware/stm32-bootloader.ts         | STM32 USART bootloader probe                                    |
  | main/firmware/board-detector.ts           | USB VID/PID board detection                                     |
  | main/firmware/manifest-fetcher.ts         | ArduPilot/Betaflight/iNav manifest parsing, HEX size conversion |
  | main/firmware/firmware-downloader.ts      | Firmware download with caching                                  |
  | packages/stm32-dfu/                       | Native TypeScript STM32 DFU library                             |
  | shared/firmware-types.ts                  | DetectedBoard, FirmwareVersion, FlashState types                |
  | shared/board-ids.ts                       | 150+ board ID mappings from ArduPilot                           |
  | shared/board-mappings.ts                  | F3 board support detection, Betaflight→iNav board mapping       |
  | stores/firmware-store.ts                  | Firmware flash UI state                                         |
  | components/firmware/FirmwareFlashView.tsx | Firmware flash UI with Connect/Auto-detect flow                 |
  | components/firmware/BoardPicker.tsx       | Searchable board dropdown                                       |
  | components/firmware/BootPadWizard.tsx     | Boot pad flash wizard for manual bootloader entry               |

  ---
  Future Epic: Setup Wizards

  Beginner-friendly wizards with visual guides - ArduDeck's key differentiator.

  Planned Wizards

  | Wizard        | Description                              | Priority |
  |---------------|------------------------------------------|----------|
  | Vehicle Setup | Frame type, motor config, receiver setup | High     |
  | Calibration   | Accelerometer, compass, radio, ESC       | High     |
  | PID Tuning    | Guided PID tuning with schematics        | Medium   |
  | First Flight  | Pre-flight checklist, safety tips        | Medium   |

  Vehicle Setup Wizard Flow

  1. Vehicle Type: Copter, Plane, VTOL, Rover, Boat
  2. Frame Config: Visual frame selection (Quad X, Hex, Flying Wing, etc.)
  3. Motor Config: Motor positions, spin directions, test buttons
  4. Receiver Setup: RX type selection with wiring diagrams
  5. Calibration: ACC/Gyro calibration with visual guides
  6. Flight Modes: Simplified mode setup for beginners
  7. Complete: Pre-flight checklist

  Design Principles

  - Visual diagrams for all frame types (SVG components)
  - Plain language explanations ("tilt your quad left" not "roll -45°")
  - Smart defaults for beginners, advanced options for experts
  - Protocol-agnostic (MAVLink/MSP abstraction layer)

  Files to Create

  components/wizards/
  ├── SetupWizard.tsx           # Main wizard container
  ├── steps/                    # Individual wizard steps
  │   ├── VehicleTypeStep.tsx
  │   ├── FrameTypeStep.tsx
  │   ├── MotorConfigStep.tsx
  │   └── ...
  ├── diagrams/                 # SVG frame diagrams
  └── WizardContext.tsx         # Wizard state management

  ---
  Future Epic: Calibration

  - Compass calibration wizard
  - Accelerometer calibration
  - Radio calibration
  - ESC calibration
  - Reference: /MissionPlanner/GCSViews/ConfigurationView/

  ---
  Future: In-App Documentation

  Plan to add .md documentation files for user help and tooltips:

  docs/help/
  ├── pid-tuning.md           # What is PID? How to tune
  ├── rates-explained.md      # RC rates, expo, super rates
  ├── flight-modes.md         # Each mode explained simply
  ├── servo-mixer.md          # Fixed-wing control surfaces
  ├── navigation-rth.md       # RTH modes, GPS requirements
  ├── failsafe.md             # What happens when things go wrong
  ├── calibration.md          # Step-by-step calibration guides
  └── glossary.md             # FPV/drone terminology

  Design:
  - Markdown files rendered in-app with help modals
  - Contextual "?" buttons next to confusing settings
  - Beginner-friendly language (no assumed knowledge)
  - Diagrams and images where helpful

  ---
  Development Workflow

  1. Analyze Legacy: Study /MissionPlanner/[relevant-file].cs
  2. Design Modern: TypeScript with strong typing
  3. Implement: React + Zustand in /apps/desktop/
  4. Test: With real hardware when possible

  Code Quality:
  - TypeScript strict mode
  - ESLint conventions
  - JSDoc for public APIs

  ---
  Hardware Context

  - Target: Pixhawk-compatible boards (SpeedyBee F405-Wing)
  - Firmware: ArduPlane with QuadPlane support
  - Use Case: VTOL delta wing for wildfire surveillance
  - Desktop Comms: USB serial (COM port)
  - Mobile Comms: Bluetooth/WiFi telemetry

  ---
  Resources

  - ArduPilot: https://ardupilot.org/
  - MAVLink: https://mavlink.io/
  - Cockpit GCS: https://github.com/bluerobotics/cockpit
  - Mission Planner: https://github.com/ArduPilot/MissionPlanner
  - ArduPilot Forums: https://discuss.ardupilot.org/
